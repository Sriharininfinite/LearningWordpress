<?php
return json_decode( '{
	"b7122312e4008f8f2c76911080bca01a": {
		"name": "Andrew Misplon",
		"email": "b7122312e4008f8f2c76911080bca01a",
		"loc": 7475,
		"score": 133.29473007391076,
		"percent": 66.92097050594654
	},
	"5cff8d4385a469d1baab761889ad3161": {
		"name": "Alex S",
		"email": "5cff8d4385a469d1baab761889ad3161",
		"loc": 1621,
		"score": 61.80936578212889,
		"percent": 31.031554977481434
	},
	"85ce7a450a7ee4895f3bd823505e2e12": {
		"name": "adiraomj",
		"email": "85ce7a450a7ee4895f3bd823505e2e12",
		"loc": 1584,
		"score": 2.4140890781373594,
		"percent": 1.2119997835411656
	},
	"43c0e7220c23bd6636cf5469be6e9612": {
		"name": "Braam Genis",
		"email": "43c0e7220c23bd6636cf5469be6e9612",
		"loc": 161,
		"score": 0.7471957376596525,
		"percent": 0.3751315891810901
	},
	"36639e6e074b731b093bde5a77305179": {
		"name": "Braam Genis",
		"email": "36639e6e074b731b093bde5a77305179",
		"loc": 575,
		"score": 0.29458742077070227,
		"percent": 0.1478983909257909
	},
	"be6a5d2323cfe9ec8246b7a677dbc65b": {
		"name": "Aaron Evans",
		"email": "be6a5d2323cfe9ec8246b7a677dbc65b",
		"loc": 22,
		"score": 0.20609344289621975,
		"percent": 0.10346975612523747
	},
	"9e7a3b2d24c2b15c53209ba8e7b4e724": {
		"name": "Kevin Batdorf",
		"email": "9e7a3b2d24c2b15c53209ba8e7b4e724",
		"loc": 22,
		"score": 0.18541056269718983,
		"percent": 0.09308586161560586
	},
	"d1bea7e3f82e561c135bf5a3d4f9f896": {
		"name": "SiteOrigin Support",
		"email": "d1bea7e3f82e561c135bf5a3d4f9f896",
		"loc": 13,
		"score": 0.12073414671411498,
		"percent": 0.06061489652918625
	},
	"d203744279876c5eda043108e2611648": {
		"name": "Alex S",
		"email": "d203744279876c5eda043108e2611648",
		"loc": 19,
		"score": 0.07530319403400175,
		"percent": 0.037806167011694446
	},
	"a885c7bd5442dd2acd8c3e42001332c6": {
		"name": "Alex S",
		"email": "a885c7bd5442dd2acd8c3e42001332c6",
		"loc": 18,
		"score": 0.02962654312035384,
		"percent": 0.014874084048566646
	},
	"07294cc1dd7658895e44c559dfffd76f": {
		"name": "gpriday",
		"email": "07294cc1dd7658895e44c559dfffd76f",
		"loc": 18,
		"score": 0.005166764222063759,
		"percent": 0.002593987593689451
	}
}', true );